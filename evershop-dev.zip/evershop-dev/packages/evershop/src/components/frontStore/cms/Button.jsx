import Button from '@components/common/form/Button';
import '@components/frontStore/cms/Button.scss';

export default Button;
